<?php
session_start();
$_SESSION['loginStatus'] = 'error';
unset($_SESSION['UserId']);
unset($_SESSION['UserName']);
unset($_SESSION['UserRole']);
unset($_SESSION['UserId']);
unset($_SESSION['loginStatus']);
session_destroy();
header("location: login");
exit;



?>