<?php
// session_start();
session_start();
// userLoginSuccess
if(isset($_SESSION['loginStatus']) && $_SESSION['loginStatus'] == 'userLoginSuccess'){
  header('location: user/dashboard');
  exit;
}elseif(isset($_SESSION['loginStatus']) && $_SESSION['loginStatus'] == 'managerLoginSuccess'){
  header('location: manager/dashboard');
  exit;
}elseif(isset($_SESSION['loginStatus']) && $_SESSION['loginStatus'] == 'adminLoginSuccess'){
  header('location: admin/dashboard');
  exit;
}else{
  header("location: login");
  exit;
}




?>