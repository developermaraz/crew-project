<?php
// generate User unique Number;
function generateUniqueNumber()
{
    $num = rand(000, 999);
    $fileName = "data.txt";
    $fp = fopen($fileName, "r");
    $inCorrect = 'notFound';
    while ($data = fgetcsv($fp)) {
        if ($data[0] == $num) {
            $inCorrect =  'found';
        }
    }
    if ($inCorrect != 'found') {
        return $num;
    } else {
        generateUniqueNumber();
    }
}
// registration process;
if (isset($_POST['registerBtn'])) {
    // connect file;
    $fileName = 'data.txt';
    // stor data in variable;
    $userName   = $_POST['userName'];
    $email      = $_POST['email'];
    $password   = $_POST['password'];
    $isError    = false;
    // check data is empty or not;
    if (empty($userName)) {
        $_SESSION['allFildsAreRequired'] = "errorMessage('error', 'User Name Is Required');";
        header("Location: register");
        exit;
    } else {
        $_SESSION['provitedUserName'] = $userName;
    }
    if (empty($email)) {
        $_SESSION['allFildsAreRequired'] = "errorMessage('error', 'Email Is Required');";
        header("Location: register");
        exit;
    } else {
        $_SESSION['provitedEmail'] = $email;
    }
    if (empty($password)) {
        $_SESSION['allFildsAreRequired'] = "errorMessage('error', 'Password Is Required');";
        header("Location: register");
        exit;
    } else {
        $password = sha1(base64_encode(md5(base64_encode($password))));
    }
    // check email is already exist or not;
    $eamilFound = "notfound";
    $fp = fopen($fileName, "r");
    while ($data = fgetcsv($fp)) {
        if ($data[1] === $email) {
            $eamilFound = "found";
        }
    }
    if ($eamilFound != "found") {
        $date = date("Y-m-d H:i:s A");
        // input data in file;
        $data = [
            "id" => generateUniqueNumber(),
            "userName" => $userName,
            "email" => $email,
            "password" => $password,
            "date" => $date,
            "role" => 'user',
        ];
        $fp = fopen($fileName, "a+");
        fputcsv($fp, $data);
        fclose($fp);
        $_SESSION['allFildsAreRequired'] = "errorMessage('success', 'Successfully Register');";
        $_SESSION['LoginStatus'] = 'success';
        unset($_SESSION['provitedUserName']);
        unset($_SESSION['provitedEmail']);
        header("Location: register");
        exit;
    } else {
        $_SESSION['allFildsAreRequired'] = "errorMessage('error', 'Email Is Already Added');";
        header("Location: register");
        exit;
    }
}
// login process;
if (isset($_POST["loginBtn"])) {
    // stor data in variable;
    $email      = $_POST["email"];
    $password   = $_POST["password"];
    $fileName   = 'data.txt';
    // check empty or not;
    if (empty($email)) {
        $_SESSION['allFildsAreRequired'] = "errorMessage('error', 'Email Is Required!');";
        header("Location: login");
        exit;
    } else {
        $_SESSION['provitedEmail'] = $email;
    }
    if (empty($password)) {
        $_SESSION['allFildsAreRequired'] = "errorMessage('error', 'Password Is Required!');";
        header("Location: login");
        exit;
    } else {
        $password = sha1(base64_encode(md5(base64_encode($password))));
    }
    // check email & password match or not;
    $file = fopen($fileName, "r");
    while ($data = fgetcsv($file)) {
        if ($data[2] === $email && $data[3] === $password) {
            $isCorrct = "found";
        }
    }
    if ($isCorrct == "found") {
        $file = fopen($fileName, "r");
        while (($line = fgets($file)) != false) {
            $data = explode(",", $line);
            if (isset($data[2]) && trim($data[2]) === $email) {
                $_SESSION['UserId'] = $data[0];
                $_SESSION['UserName'] = $data[1];
                $_SESSION['UserRole'] = trim($data[5]);
                break;
            }
        }
        if ($_SESSION['UserRole'] == 'user') {
            $_SESSION['loginStatus'] = 'userLoginSuccess';
            header("Location: user/dashboard.php");
            exit;
        } else if ($_SESSION['UserRole'] == 'manager') {
            $_SESSION['loginStatus'] = 'managerLoginSuccess';
            header("Location: manager/dashboard.php");
            exit;
        } elseif ($_SESSION['UserRole'] == 'admin') {
            $_SESSION['loginStatus'] = 'adminLoginSuccess';
            header("Location: admin/dashboard.php");
            exit;
        } else {
            echo 'done';
            exit;
        }
    } else {
        $_SESSION['allFildsAreRequired'] = "errorMessage('error', 'Incorrect Email & Password!');";
        header("Location: login.php");
        exit;
    }
}
// get user data;
function collectDataById($id)
{
    $file = '../data.txt';
    $fp = fopen($file, 'r');
    while ($data = fgetcsv($fp)) {
        if ($data[0] == $id) {
            break;
        }
    }
    $userData = [$data[0], $data[1], $data[2], $data[3], $data[4], $data[5]];
    return $userData;
}
// get all user;
function getAllUser()
{
    $file = '../data.txt';
    $data = [];
    $fp = fopen($file, 'r');
    while ($line = fgetcsv($fp)) {
        $data[] = $line;
    }
    return $data;
}
// update user profile process;
if (isset($_POST['updateUserProfileBtn'])) {
    // stor data in variable;
    $userId     = $_POST['userId'];
    $userName   = $_POST['userName'];
    $userEmail  = $_POST['userEmail'];
    $path       = $_POST['path'];
    if (empty($userName)) {
        $_SESSION['allFildsAreRequired'] = "errorMessage('error', 'User Name Is Required!');";
        header("Location: ../$path");
        exit;
    }
    if (empty($userEmail)) {
        $_SESSION['allFildsAreRequired'] = "errorMessage('error', 'User Email Is Required!');";
        header("Location: ../$path");
        exit;
    }
    $file = "../data.txt";
    $lines = [];

    // Read the file and exclude lines with '295'
    $ff = fopen($file, "r");
    while ($row = fgetcsv($ff)) {
        if ($row[0] == $userId) {
            break;
        }
    }
    $userData = [
        'id' =>      $row[0],
        'name' =>    $userName,
        'eamil' =>   $userEmail,
        'pass' =>    $row[3],
        'date' =>    $row[4],
        'user' =>    $row[5]
    ];
    fclose($ff);
    $dd = fopen($file, "r");
    while ($data = fgetcsv($dd)) {
        if ($data[0] != $userId) {
            $lines[] = $data;
        }
    }
    fclose($dd);
    // Write the updated content back to the file
    $fp = fopen($file, "w");
    foreach ($lines as $data) {
        fputcsv($fp, $data);
    }
    fclose($fp);
    $fp = fopen($file, "a");
    fputcsv($fp, $userData);
    fclose($fp);
    $_SESSION['allFildsAreRequired'] = "errorMessage('success', 'Successfully Updated');";
    header("Location: ../$path");
    exit;
}
// update user password;
if (isset($_POST["updateUserPasswordBtn"])) {
    // stor data in variable;
    $currentPass    = $_POST["currentPass"];
    $newPass        = $_POST["newPass"];
    $conPass        = $_POST["conPass"];
    $userId         = $_POST["userId"];
    $path           = $_POST["path"];
    // check emtpy or not;
    if (empty($currentPass)) {
        $_SESSION['allFildsAreRequired'] = "errorMessage('error', 'Current Password Is Required!');";
        header("Location: ../$path");
        exit;
    } else {
        $_SESSION['currentPassword'] = $currentPass;
    }
    if (empty($newPass)) {
        $_SESSION['allFildsAreRequired'] = "errorMessage('error', 'New Password Is Required!');";
        header("Location: ../$path");
        exit;
    } else {
        $_SESSION['newPassword'] = $newPass;
    }
    if (empty($conPass)) {
        $_SESSION['allFildsAreRequired'] = "errorMessage('error', 'Confirm Password Is Required!');";
        header("Location: ../$path");
        exit;
    } else {
        $_SESSION['conPassPassword'] = $conPass;
    }
    if ($newPass != $conPass) {
        $_SESSION['allFildsAreRequired'] = "errorMessage('error', 'Password Does Not Match!');";
        header("Location: ../$path");
        exit;
    } else {
        // encode 3 password;
        $currPass   = sha1(base64_encode(md5(base64_encode($currentPass))));
        $newPass    = sha1(base64_encode(md5(base64_encode($newPass))));
        $conPass    = sha1(base64_encode(md5(base64_encode($conPass))));
        // file name;
        $fileName = "../data.txt";
        $file = fopen($fileName, "r");
        $pSt = 'NotFound';
        while ($data = fgetcsv($file)) {
            if ($data[0] === $userId && $data[3] === $currPass) {
                $pSt = 'Found';
                break;
            }
        }
        if ($pSt == 'NotFound') {
            $_SESSION['allFildsAreRequired'] = "errorMessage('error', 'Wrong Password!');";
            header("Location: ../$path");
            exit;
        } else {
            fclose($file);
            $file = "../data.txt";
            $lines = [];
            // Read the file and exclude lines with '295'
            $ff = fopen($file, "r");
            while ($row = fgetcsv($ff)) {
                if ($row[0] == $userId) {
                    break;
                }
            }
            $userData = [
                'id' =>      $row[0],
                'name' =>    $row[1],
                'eamil' =>   $row[2],
                'pass' =>    $conPass,
                'date' =>    $row[4],
                'user' =>    $row[5]
            ];
            fclose($ff);
            $dd = fopen($file, "r");
            while ($data = fgetcsv($dd)) {
                if ($data[0] != $userId) {
                    $lines[] = $data;
                }
            }
            fclose($dd);
            // Write the updated content back to the file
            $fp = fopen($file, "w");
            foreach ($lines as $data) {
                fputcsv($fp, $data);
            }
            fclose($fp);
            $fp = fopen($file, "a");
            fputcsv($fp, $userData);
            fclose($fp);
            unset($_SESSION['currentPassword']);
            unset($_SESSION['newPassword']);
            unset($_SESSION['conPassPassword']);
            $_SESSION['allFildsAreRequired'] = "errorMessage('success', 'Successfully Change!');";
            header("Location: ../$path");
            exit;
        }
    }
}
if (isset($_GET['operation_type']) && $_GET['operation_type'] == 'chagneRoleUser') {
    $id = $_POST['id'];
    $role = $_POST['role'];
    $file = "../data.txt";
    $lines = [];

    // Read the file and exclude lines with '295'
    $ff = fopen($file, "r");
    while ($row = fgetcsv($ff)) {
        if ($row[0] == $id) {
            break;
        }
    }
    $userData = [
        'id' =>      $row[0],
        'name' =>    $row[1],
        'eamil' =>   $row[2],
        'pass' =>    $row[3],
        'date' =>    $row[4],
        'user' =>    $role
    ];
    fclose($ff);
    $dd = fopen($file, "r");
    while ($data = fgetcsv($dd)) {
        if ($data[0] != $id) {
            $lines[] = $data;
        }
    }
    fclose($dd);
    // Write the updated content back to the file
    $fp = fopen($file, "w");
    foreach ($lines as $data) {
        fputcsv($fp, $data);
    }
    fclose($fp);
    $fp = fopen($file, "a");
    fputcsv($fp, $userData);
    fclose($fp);
    $response = 'success';
    echo $response;
}
